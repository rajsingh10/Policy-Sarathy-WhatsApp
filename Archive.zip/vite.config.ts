import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    proxy: {
      "/api": {
        target: "https://whatsapp-bulk.fableadtech.com/services",
        changeOrigin: true,
        secure: false,
      },
      "/cors-proxy": {
        target: "https://whatsapp-bulk.fableadtech.com/services",
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/cors-proxy/, ''),
      },
    },
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(
    Boolean,
  ),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));
